#include <iostream>
#include <vector>
#pragma once
using namespace std;
class SinhVien
{
public:
	void nhap();
	void xuat();
	float gdtb();
	char ten[30];
	SinhVien();
	~SinhVien();
	char mssv[30];
	float dtb;

};

